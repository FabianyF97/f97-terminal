/**
 * ==========================================
 * F97 - SISTEMA CENTRAL DE OPERACIONES
 * Versión Final SEO Optimizada 2026
 * ==========================================
 */

/* ==========================================
   CONFIGURACIÓN GENERAL
========================================== */

const PRECIO_TIQUETE = 45000;
let asientosSeleccionados = [];

/* ==========================================
   INICIALIZACIÓN DEL SISTEMA
========================================== */

document.addEventListener('DOMContentLoaded', () => {

    console.log("🚀 F97 Engine: Sistema inicializado correctamente");

    // Inicializar íconos Lucide
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Mejorar rendimiento SEO
    optimizarImagenes();

    // Animación suave al cargar
    document.body.classList.add('loaded');

    /* ==========================================
       FORMULARIO DE RESERVA
    ========================================== */

    const formReserva = document.querySelector('form[action="confirmacion.html"]');

    if (formReserva) {

        formReserva.addEventListener('submit', (e) => {

            // Validación SEO + UX
            if (asientosSeleccionados.length === 0) {
                e.preventDefault();

                mostrarAlerta(
                    "⚠️ Por favor, selecciona al menos un asiento antes de continuar."
                );

                return;
            }

            // Obtener nombre del pasajero
            const nombrePasajero = formReserva.querySelector('input[type="text"]').value.trim();

            // Validación básica
            if (nombrePasajero.length < 3) {
                e.preventDefault();

                mostrarAlerta(
                    "⚠️ Ingresa un nombre válido."
                );

                return;
            }

            // Guardar datos en LocalStorage
            localStorage.setItem('f97_nombre', nombrePasajero);
            localStorage.setItem('f97_asientos', asientosSeleccionados.join(', '));
            localStorage.setItem(
                'f97_total',
                asientosSeleccionados.length * PRECIO_TIQUETE
            );

            // Loader visual
            const btn = formReserva.querySelector('button');

            if (btn) {
                btn.innerHTML = `
                    <i data-lucide="loader-2" class="animate-spin"></i>
                    Procesando Pago...
                `;

                lucide.createIcons();
            }
        });
    }

    /* ==========================================
       PÁGINA DE CONFIRMACIÓN
    ========================================== */

    if (window.location.pathname.includes('confirmacion.html')) {

        const txtNombre = document.getElementById('ticket-name');
        const txtAsientos = document.getElementById('ticket-seats');
        const txtTotal = document.getElementById('ticket-total');

        if (txtNombre) {
            txtNombre.innerText =
                localStorage.getItem('f97_nombre') || "Pasajero F97";
        }

        if (txtAsientos) {
            txtAsientos.innerText =
                localStorage.getItem('f97_asientos') || "Sin asignar";
        }

        if (txtTotal) {

            const total = localStorage.getItem('f97_total') || "0";

            txtTotal.innerText =
                `$${Number(total).toLocaleString()}`;
        }
    }

    /* ==========================================
       EFECTO SCROLL NAVBAR
    ========================================== */

    window.addEventListener('scroll', () => {

        const navbar = document.querySelector('.navbar');

        if (!navbar) return;

        if (window.scrollY > 50) {
            navbar.classList.add('navbar-scroll');
        } else {
            navbar.classList.remove('navbar-scroll');
        }
    });
});

/* ==========================================
   FUNCIÓN SELECCIÓN DE ASIENTOS
========================================== */

function toggleAsiento(elemento, numeroAsiento) {

    if (elemento.classList.contains('ocupado')) return;

    if (elemento.classList.contains('disponible')) {

        elemento.classList.replace('disponible', 'seleccionado');

        asientosSeleccionados.push(numeroAsiento);

    } else {

        elemento.classList.replace('seleccionado', 'disponible');

        asientosSeleccionados =
            asientosSeleccionados.filter(a => a !== numeroAsiento);
    }

    actualizarPrecio();
}

/* ==========================================
   ACTUALIZAR PRECIO
========================================== */

function actualizarPrecio() {

    const txtPrecio = document.getElementById('total-price');

    if (!txtPrecio) return;

    const total = asientosSeleccionados.length * PRECIO_TIQUETE;

    txtPrecio.innerText = `$${total.toLocaleString()}`;
}

/* ==========================================
   FILTRO DE RUTAS
========================================== */

function filtrarRutas(valor) {

    const term = valor.toLowerCase();

    const tarjetas = document.querySelectorAll('.ruta-card');

    tarjetas.forEach(card => {

        const texto = card.innerText.toLowerCase();

        card.style.display =
            texto.includes(term) ? 'flex' : 'none';
    });
}

/* ==========================================
   ENVIAR COTIZACIÓN A WHATSAPP
========================================== */

function enviarCotizacion(event) {

    event.preventDefault();

    // ⬇️ CAMBIAR POR TU NÚMERO
    const miWhatsApp = "573100000000";

    const nombre =
        event.target.querySelector('input[placeholder*="Nombre"]').value;

    const servicio =
        event.target.querySelector('select').value;

    const detalles =
        event.target.querySelector('textarea').value;

    const mensaje =
        `*F97 - Nueva Cotización*%0A` +
        `*Cliente:* ${nombre}%0A` +
        `*Servicio:* ${servicio}%0A` +
        `*Detalles:* ${detalles}`;

    window.open(
        `https://wa.me/${miWhatsApp}?text=${mensaje}`,
        '_blank'
    );
}

/* ==========================================
   ALERTA PERSONALIZADA
========================================== */

function mostrarAlerta(mensaje) {

    alert(mensaje);
}

/* ==========================================
   OPTIMIZACIÓN SEO DE IMÁGENES
========================================== */

function optimizarImagenes() {

    const imagenes = document.querySelectorAll('img');

    imagenes.forEach(img => {

        // Lazy Loading SEO
        img.setAttribute('loading', 'lazy');

        // ALT automático si no existe
        if (!img.getAttribute('alt')) {
            img.setAttribute(
                'alt',
                'Imagen del sistema de transporte F97'
            );
        }
    });
}

/* ==========================================
   ANIMACIÓN SUAVE AL CARGAR
========================================== */

window.addEventListener('load', () => {

    document.body.style.opacity = "1";
});

/* ==========================================
   DETECCIÓN DE CONEXIÓN
========================================== */

window.addEventListener('offline', () => {

    mostrarAlerta(
        "⚠️ No tienes conexión a internet."
    );
});

window.addEventListener('online', () => {

    console.log("✅ Conexión restaurada.");
});