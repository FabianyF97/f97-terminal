/**
 * F97 - SISTEMA CENTRAL DE OPERACIONES
 * Versión Final 2026
 */

// Configuración de Precios
const PRECIO_TIQUETE = 45000;
let asientosSeleccionados = [];

document.addEventListener('DOMContentLoaded', () => {
    console.log("🚀 F97 Engine: Sistema inicializado");
    
    // Inicializar iconos de Lucide
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // --- LÓGICA DE LA PÁGINA DE RESERVA ---
    const formReserva = document.querySelector('form[action="confirmacion.html"]');
    if (formReserva) {
        formReserva.addEventListener('submit', (e) => {
            if (asientosSeleccionados.length === 0) {
                e.preventDefault();
                alert("⚠️ Por favor, selecciona al menos un asiento antes de pagar.");
                return;
            }
            
            // Guardar datos para que la página de confirmación los lea
            const nombrePasajero = formReserva.querySelector('input[type="text"]').value;
            localStorage.setItem('f97_nombre', nombrePasajero);
            localStorage.setItem('f97_asientos', asientosSeleccionados.join(', '));
            localStorage.setItem('f97_total', asientosSeleccionados.length * PRECIO_TIQUETE);
            
            // Simulación de carga (Opcional)
            const btn = formReserva.querySelector('button');
            btn.innerHTML = `<i data-lucide="loader-2" class="animate-spin"></i> Procesando Pago...`;
            lucide.createIcons();
        });
    }

    // --- LÓGICA DE LA PÁGINA DE CONFIRMACIÓN ---
    if (window.location.pathname.includes('confirmacion.html')) {
        const txtNombre = document.getElementById('ticket-name');
        const txtAsientos = document.getElementById('ticket-seats');
        const txtTotal = document.getElementById('ticket-total');

        if (txtNombre) txtNombre.innerText = localStorage.getItem('f97_nombre') || "Pasajero F97";
        if (txtAsientos) txtAsientos.innerText = localStorage.getItem('f97_asientos') || "Sin asignar";
        if (txtTotal) {
            const total = localStorage.getItem('f97_total') || "0";
            txtTotal.innerText = `$${Number(total).toLocaleString()}`;
        }
    }
});

/**
 * Función para seleccionar asientos (Usada en tiquetes/reserva.html)
 */
function toggleAsiento(elemento, numeroAsiento) {
    if (elemento.classList.contains('ocupado')) return;

    if (elemento.classList.contains('disponible')) {
        elemento.classList.replace('disponible', 'seleccionado');
        asientosSeleccionados.push(numeroAsiento);
    } else {
        elemento.classList.replace('seleccionado', 'disponible');
        asientosSeleccionados = asientosSeleccionados.filter(a => a !== numeroAsiento);
    }

    // Actualizar el precio en pantalla
    const txtPrecio = document.getElementById('total-price');
    if (txtPrecio) {
        const total = asientosSeleccionados.length * PRECIO_TIQUETE;
        txtPrecio.innerText = `$${total.toLocaleString()}`;
    }
}

/**
 * Función de Búsqueda (Usada en rutas/index.html)
 */
function filtrarRutas(valor) {
    const term = valor.toLowerCase();
    const tarjetas = document.querySelectorAll('.ruta-card');

    tarjetas.forEach(card => {
        const texto = card.innerText.toLowerCase();
        card.style.display = texto.includes(term) ? 'flex' : 'none';
    });
}

/**
 * Enviar Cotización a WhatsApp (Usada en cotizacion.html)
 */
function enviarCotizacion(event) {
    event.preventDefault();
    
    const miWhatsApp = "573100000000"; // ⬅️ CAMBIA ESTE NÚMERO POR EL TUYO
    
    const nombre = event.target.querySelector('input[placeholder*="Nombre"]').value;
    const servicio = event.target.querySelector('select').value;
    const detalles = event.target.querySelector('textarea').value;

    const mensaje = `*F97 - Nueva Cotización*%0A` +
                    `*Cliente:* ${nombre}%0A` +
                    `*Servicio:* ${servicio}%0A` +
                    `*Detalles:* ${detalles}`;

    window.open(`https://wa.me/${miWhatsApp}?text=${mensaje}`, '_blank');
}