<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("conexion.php");

$origen = $_POST['origen'] ?? '';
$destino = $_POST['destino'] ?? '';
$fecha = $_POST['fecha'] ?? '';

$sql = "SELECT * FROM rutas 
        WHERE origen LIKE '%$origen%' 
        AND destino LIKE '%$destino%'";

$resultado = $conexion->query($sql);

if (!$resultado) {
    die("Error en SQL: " . $conexion->error);
}
?>

<h1>Rutas disponibles</h1>

<?php if ($resultado->num_rows > 0) { ?>

    <?php while($r = $resultado->fetch_assoc()) { ?>
        
        <form action="reservar.php" method="POST">
            <input type="hidden" name="id_ruta" value="<?php echo $r['id']; ?>">
            <input type="hidden" name="fecha" value="<?php echo $fecha; ?>">

            <h3><?php echo $r['origen']." → ".$r['destino']; ?></h3>
            <p><?php echo $r['hora']; ?> - $<?php echo $r['precio']; ?></p>

            <button type="submit">Seleccionar</button>
        </form>

    <?php } ?>

<?php } else { ?>

    <p>No hay rutas disponibles</p>

<?php } ?>