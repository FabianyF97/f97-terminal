<?php
include("conexion.php");

$id_ruta = $_POST['id_ruta'];
$fecha = $_POST['fecha'];

$sql = "SELECT * FROM rutas WHERE id = $id_ruta";
$ruta = $conexion->query($sql)->fetch_assoc();
?>

<h1>Completa tu reserva</h1>

<form action="guardar_reserva.php" method="POST">

    <input type="hidden" name="id_ruta" value="<?php echo $id_ruta; ?>">
    <input type="hidden" name="fecha" value="<?php echo $fecha; ?>">

    <p><?php echo $ruta['origen'] . " → " . $ruta['destino']; ?></p>

    <input type="text" name="nombre" placeholder="Nombre completo" required>
    <input type="text" name="cedula" placeholder="Cédula" required>
    <input type="number" name="asientos" placeholder="Cantidad de asientos" required>

    <button type="submit">Confirmar Reserva</button>
</form>
