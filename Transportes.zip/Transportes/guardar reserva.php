<?php
include("conexion.php");

$id_ruta = $_POST['id_ruta'];
$fecha = $_POST['fecha'];
$nombre = $_POST['nombre'];
$cedula = $_POST['cedula'];
$asientos = $_POST['asientos'];

$sql = "INSERT INTO reservas (id_ruta, fecha, nombre, cedula, asientos)
        VALUES ('$id_ruta', '$fecha', '$nombre', '$cedula', '$asientos')";

$conexion->query($sql);

$id_reserva = $conexion->insert_id;

header("Location: tiquete.php?id=$id_reserva");
?>