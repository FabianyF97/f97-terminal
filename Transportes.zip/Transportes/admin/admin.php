<?php
include("../conexion.php");

$result = $conexion->query("SELECT * FROM rutas ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Admin F97</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 p-10">

<h1 class="text-3xl font-black mb-6 text-emerald-600">Panel Admin F97</h1>

<a href="crear_ruta.php" class="bg-emerald-600 text-white px-5 py-2 rounded-xl">
    + Nueva Ruta
</a>

<div class="mt-6 space-y-4">
<?php while($r = $result->fetch_assoc()) { ?>
    
    <div class="bg-white p-6 rounded-xl shadow flex justify-between items-center">
        <div>
            <h2 class="font-bold text-lg">
                <?php echo $r['origen']." → ".$r['destino']; ?>
            </h2>
            <p>Hora: <?php echo $r['hora']; ?> | $<?php echo $r['precio']; ?></p>
        </div>

        <div class="space-x-2">
            <a href="editar_ruta.php?id=<?php echo $r['id']; ?>" class="bg-blue-500 text-white px-3 py-1 rounded">
                Editar
            </a>

            <a href="eliminar_ruta.php?id=<?php echo $r['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded">
                Eliminar
            </a>
        </div>
    </div>

<?php } ?>
</div>

</body>
</html>