<?php
include("../conexion.php");

$id = $_GET['id'];
$r = $conexion->query("SELECT * FROM rutas WHERE id=$id")->fetch_assoc();
?>

<form action="actualizar_ruta.php" method="POST">

<input type="hidden" name="id" value="<?php echo $r['id']; ?>">

<input type="text" name="origen" value="<?php echo $r['origen']; ?>">
<input type="text" name="destino" value="<?php echo $r['destino']; ?>">
<input type="text" name="hora" value="<?php echo $r['hora']; ?>">
<input type="number" name="precio" value="<?php echo $r['precio']; ?>">

<button>Actualizar</button>

</form>