<?php
include("../conexion.php");

$id = $_GET['id'];

$conexion->query("DELETE FROM rutas WHERE id=$id");

header("Location: admin.php");
?>