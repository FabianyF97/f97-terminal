<?php
include("../conexion.php");

$origen = $_POST['origen'];
$destino = $_POST['destino'];
$hora = $_POST['hora'];
$precio = $_POST['precio'];

$sql = "INSERT INTO rutas (origen, destino, hora, precio)
        VALUES ('$origen', '$destino', '$hora', '$precio')";

$conexion->query($sql);

header("Location: admin.php");
?>