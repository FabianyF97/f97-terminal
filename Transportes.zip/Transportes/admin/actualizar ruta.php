<?php
include("../conexion.php");

$id = $_POST['id'];
$origen = $_POST['origen'];
$destino = $_POST['destino'];
$hora = $_POST['hora'];
$precio = $_POST['precio'];

$sql = "UPDATE rutas 
        SET origen='$origen', destino='$destino', hora='$hora', precio='$precio'
        WHERE id=$id";

$conexion->query($sql);

header("Location: admin.php");
?>