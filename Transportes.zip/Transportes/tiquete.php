<?php
include("conexion.php");

$id = $_GET['id'];

$sql = "SELECT r.*, ru.origen, ru.destino, ru.hora, ru.precio 
        FROM reservas r
        JOIN rutas ru ON r.id_ruta = ru.id
        WHERE r.id = $id";

$reserva = $conexion->query($sql)->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tiquete F97</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex justify-center items-center h-screen">

<div class="bg-white p-8 rounded-2xl shadow-xl w-96 text-center">

    <h1 class="text-2xl font-bold text-emerald-600 mb-4">🎟️ Tiquete F97</h1>

    <p><b>Pasajero:</b> <?php echo $reserva['nombre']; ?></p>
    <p><b>Cédula:</b> <?php echo $reserva['cedula']; ?></p>

    <hr class="my-3">

    <p><b>Ruta:</b> <?php echo $reserva['origen'] . " → " . $reserva['destino']; ?></p>
    <p><b>Hora:</b> <?php echo $reserva['hora']; ?></p>
    <p><b>Fecha:</b> <?php echo $reserva['fecha']; ?></p>
    <p><b>Asientos:</b> <?php echo $reserva['asientos']; ?></p>

    <hr class="my-3">

    <p class="text-lg font-bold">Total: $<?php echo $reserva['precio'] * $reserva['asientos']; ?></p>

    <button onclick="window.print()" class="mt-4 bg-emerald-600 text-white px-4 py-2 rounded">
        Imprimir
    </button>

</div>

</body>
</html>